<?php 
$username = "root";
$password=""; //YOUR LOCALHOST PASSWORD
if ($pdo = new PDO('mysql:host=localhost;dbname=foodorder;port=3308', $username, $password)){}else{
echo "not connected";}

$pdo-> exec("set names utf8");
?> 